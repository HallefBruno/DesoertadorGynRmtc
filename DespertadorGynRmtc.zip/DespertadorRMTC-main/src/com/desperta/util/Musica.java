package com.desperta.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.Player;

/**
 *
 * @author hallef
 */
public class Musica extends Thread {

    private String caminho;
    private Player player;

    public String getCaminho() {
        return caminho;
    }

    public void setCaminho(String caminho) {
        this.caminho = caminho;
    }

    public void close() {
        if (player != null) {
            player.close();
        }
    }

    @Override
    public void run() {
        FileInputStream fileInputStream;
        try {
            fileInputStream = new FileInputStream(caminho);
            player = new Player((fileInputStream));
            player.play();
        } catch (FileNotFoundException | JavaLayerException ex) {
            Logger.getLogger(Musica.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
