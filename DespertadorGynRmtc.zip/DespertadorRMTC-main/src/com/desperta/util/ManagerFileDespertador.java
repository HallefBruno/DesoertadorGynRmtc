package com.desperta.util;

import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hallef
 */
public class ManagerFileDespertador {

    public static final String LOCAL_PROJETO = System.getProperty("user.dir");
    public static final String NOME_PASTA_ESCALA_C = "EscalaCompleta";
    public static final String NOME_ARQUIVOC = "EscalasCompleta-" + dataHoraFormatada() + ".txt";
    public static final String NOME_PASTA_ESCALADH = "EscalaDH";
    public static final String NOME_ARQUIVO_ESCALADH = "EscalasDH-" + dataHoraFormatada() + ".txt";

    public void criaPastaArquivo(String path) throws FileNotFoundException, IOException {

        PdfReader pdfReader = new PdfReader(path);
        StringBuilder sb = new StringBuilder();
        for (int i = 1; i <= pdfReader.getNumberOfPages(); i++) {
            sb.append(PdfTextExtractor.getTextFromPage(pdfReader, i));
        }
        pdfReader.close();

        criarPasta(LOCAL_PROJETO + File.separator + NOME_PASTA_ESCALA_C);
        File escreveEscalaC = criarArquivo(LOCAL_PROJETO + File.separator + NOME_PASTA_ESCALA_C + File.separator + NOME_ARQUIVOC);

        try (PrintWriter pw = new PrintWriter(escreveEscalaC)) {
            pw.print(sb.toString());
        }

        criarPasta(LOCAL_PROJETO + File.separator + NOME_PASTA_ESCALADH);
        File escrveEscalaDH = criarArquivo(LOCAL_PROJETO + File.separator + NOME_PASTA_ESCALADH + File.separator + NOME_ARQUIVO_ESCALADH);

        List<String> listDataHora;
        try (BufferedReader br = new BufferedReader(new FileReader(LOCAL_PROJETO + File.separator + NOME_PASTA_ESCALA_C + File.separator + NOME_ARQUIVOC))) {
            listDataHora = new ArrayList<>();
            String strEscala;
            String data;
            String hora;
            int key = 1;
            while (br.ready()) {
                strEscala = br.readLine();
                if (strEscala.contains("LGR")) {
                    data = strEscala.substring(0, strEscala.indexOf(" "));
                    hora = strEscala.substring(strEscala.indexOf("Gar") + 4, strEscala.indexOf("Gar") + 9);
                    listDataHora.add(key + ";" + data + ";" + hora);
                    key++;
                }
            }
        }

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(escrveEscalaDH))) {
            for (int i = 0; i < listDataHora.size(); i++) {
                bw.write(listDataHora.get(i));
                if (i + 1 < listDataHora.size()) {
                    bw.newLine();
                }
            }
        }

    }

    public void escalaComun(String caminho) throws FileNotFoundException, IOException {
        File escrveEscalaDH = criarPastaSubDiretorio(LOCAL_PROJETO + File.separator + "EscalasDefault");
        List<String> listDataHora;
        try (BufferedReader br = new BufferedReader(new FileReader(caminho))) {
            listDataHora = new ArrayList<>();
            String linha;
            String data;
            String hora;
            int key = 1;

            while ((linha = br.readLine()) != null) {
                String[] coluna = linha.split(";");
                data = coluna[0];
                hora = coluna[1];
                listDataHora.add(key + ";" + data + ";" + hora);
                key++;
                System.out.println(key + ";" + data + ";" + hora);
            }

        }

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(escrveEscalaDH + File.separator + "escala.txt"))) {
            for (int i = 0; i < listDataHora.size(); i++) {
                bw.write(listDataHora.get(i));
                if (i + 1 < listDataHora.size()) {
                    bw.newLine();
                }
            }
        }
    }

    public File criarPasta(String path) {
        File file = new File(path);
        if (!file.isDirectory()) {
            file.mkdir();
        }
        return file;
    }

    public File criarPastaSubDiretorio(String path) {
        File file = new File(path);
        if (!file.isDirectory()) {
            file.mkdirs();
        }
        return file;
    }

    public File criarArquivo(String path) throws IOException {
        File file = new File(path);
        if (!file.isFile()) {
            file.createNewFile();
        }
        return file;
    }

    public void deletePastas(String... paths) {
        File file;
        for (String s : paths) {
            file = new File(s);
            if (file.isDirectory()) {
                for (File f : file.listFiles()) {
                    f.delete();
                }
            }
            file.delete();
        }
    }

    public void copiador(String source) {

        try {
            File file = new File(source);
            File criaPas = new File(LOCAL_PROJETO + File.separator + "Music");
            if (!criaPas.isDirectory()) {
                criaPas.mkdir();
            }
            File cp = new File(criaPas + File.separator + "toque.mp3");

            Files.copy(file.toPath(), cp.toPath(), StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException ex) {
            Logger.getLogger(ManagerFileDespertador.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public static String dataHoraFormatada() {
        Date dataHoraAtual = new Date();
        String data = new SimpleDateFormat("dd/MM/yyyy").format(dataHoraAtual);
        String hora = new SimpleDateFormat("HH:mm:ss").format(dataHoraAtual);
        data = data.replace("/", "_");
        hora = hora.replace(":", "_");
        return data + "-" + hora;
    }

}
