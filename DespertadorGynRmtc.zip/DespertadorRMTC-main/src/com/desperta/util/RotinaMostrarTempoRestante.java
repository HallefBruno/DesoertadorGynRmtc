package com.desperta.util;

import com.desperta.model.Escala;
import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import org.joda.time.DateTime;
import org.joda.time.Days;
import org.joda.time.Period;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

/**
 *
 * @author hallef
 */
public class RotinaMostrarTempoRestante extends Thread {

    private Period period;
    private DateTimeFormatter format;
    private DateTime dtInicial;
    private DateTime dtFinal;
    private SimpleDateFormat simpleDateFormat;
    private List<Escala> escalas;
    private Date date;
    private JLabel labelDisplay;
    private DefaultTableModel defaultTableModel;
    private JLabel lbmessage;
    private JLabel labelGif;
    private JLabel labelHoraEscala;
    private JTable jtbescalas;

    public RotinaMostrarTempoRestante(List<Escala> escalas, JLabel labelDisplay, JLabel lbmessage, JLabel labelGif, JLabel labelHoraEscala, JTable jtbescalas) {

        this.escalas = escalas;
        this.format = DateTimeFormat.forPattern("dd/MM/yyyy HH:mm:ss");
        this.dtInicial = new DateTime();
        this.simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        this.labelDisplay = labelDisplay;
        this.lbmessage = lbmessage;
        this.labelGif = labelGif;
        this.jtbescalas = jtbescalas;
        this.labelHoraEscala = labelHoraEscala;
    }

    @Override
    public void run() {

        try {

            int dias;
            int horas;
            int minutos;
            int segundos;

            defaultTableModel = (DefaultTableModel) jtbescalas.getModel();
            defaultTableModel.fireTableStructureChanged();

            while (defaultTableModel.getRowCount() > 0) {
                defaultTableModel.removeRow(0);
            }

            escalas.forEach((es) -> {
                defaultTableModel.addRow(new Object[]{es.getId(), es.getData(), es.getHora()});
            });

            labelHoraEscala.setText(escalas.get(0).getData() + " " + escalas.get(0).getHora() + ":00");

            while (true) {

                if (!escalas.isEmpty()) {

                    date = Calendar.getInstance().getTime();
                    dtFinal = new DateTime(format.parseDateTime(escalas.get(0).getData() + " " + escalas.get(0).getHora() + ":00"));
                    dtInicial = format.parseDateTime(this.simpleDateFormat.format(date));
                    period = new Period(dtInicial, dtFinal);

                    dias = Days.daysBetween(dtInicial, dtFinal).getDays();
                    horas = period.getHours();
                    minutos = period.getMinutes();
                    segundos = period.getSeconds();

                    if (dias >= 0 && horas >= 0 && minutos >= 0 && segundos >= 0) {
                        labelDisplay.setText("Falta " + dias + " Dias, " + horas + " Horas e " + minutos + " Minutos " + segundos);
                    } else if (dias == 0 && horas == 0 && minutos == 0 && segundos < 0) {
                        acionarToque();
                        labelDisplay.setText("Falta " + dias + " Dias, " + horas + " Horas e " + minutos + " Minutos " + segundos);
                        escalas.remove(0);
                        if (!escalas.isEmpty()) {
                            labelHoraEscala.setText(escalas.get(0).getData() + " " + escalas.get(0).getHora() + ":00");
                        }
                        refreshTable();
                    } else if (dias < 0 || horas < 0 || minutos < 0 && segundos < 0) {
                        try {
                            SimpleDateFormat formata = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
                            Calendar dataEscala = new GregorianCalendar();
                            Calendar dataAtual = new GregorianCalendar();
                            Date data = new GregorianCalendar().getTime();

                            for (int i = escalas.size(); i > 0; i--) {
                                dataAtual.setTime(formata.parse(formata.format(data)));
                                dataEscala.setTime(formata.parse(escalas.get(0).getData() + " " + escalas.get(0).getHora() + ":00"));
                                if (dataAtual.getTimeInMillis() > dataEscala.getTimeInMillis()) {
                                    escalas.remove(0);
                                    if (!escalas.isEmpty()) {
                                        labelHoraEscala.setText(escalas.get(0).getData() + " " + escalas.get(0).getHora() + ":00");
                                    }
                                    refreshTable();
                                }
                            }

                        } catch (ParseException ex) {
                            Logger.getLogger(RotinaMostrarTempoRestante.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }

                } else {
                    break;
                }

                Thread.sleep(1000);
            }

        } catch (InterruptedException ex) {
            Logger.getLogger(RotinaMostrarTempoRestante.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    private void refreshTable() {

        defaultTableModel = (DefaultTableModel) jtbescalas.getModel();
        defaultTableModel.fireTableStructureChanged();

        while (defaultTableModel.getRowCount() > 0) {
            defaultTableModel.removeRow(0);
        }

        escalas.forEach((es) -> {
            defaultTableModel.addRow(new Object[]{es.getId(), es.getData(), es.getHora()});
        });

        if (escalas.isEmpty()) {
            labelDisplay.setText("");
            lbmessage.setText("Faça uma nova importação!");
            labelHoraEscala.setText("");
            labelGif.setVisible(false);

            TableColumnModel cm = jtbescalas.getColumnModel();
            while (cm.getColumnCount() > 0) {
                TableColumn column = cm.getColumn(0);
                cm.removeColumn(column);
            }

        }
    }

    private void acionarToque() {
        try {
            Musica m = new Musica();
            m.setCaminho(System.getProperty("user.dir") + File.separator + "Music" + File.separator + "toque.mp3");
            m.start();
            labelGif.setVisible(true);
            Thread.sleep(1000 * 20);
            m.close();
            labelGif.setVisible(false);
        } catch (InterruptedException ex) {
            Logger.getLogger(RotinaMostrarTempoRestante.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
}
