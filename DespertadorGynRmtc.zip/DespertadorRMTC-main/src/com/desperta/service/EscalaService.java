package com.desperta.service;

import com.desperta.model.Escala;
import com.desperta.repository.EscalaRepository;
import com.desperta.util.RotinaMostrarTempoRestante;
import java.awt.Component;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JLabel;

/**
 *
 * @author hallef
 */
public class EscalaService implements EscalaRepository {

    @Override
    public void save(List<Escala> escala) {
    }

    @Override
    public List<Escala> escalas() {
        List<Escala> escalas = new ArrayList<>();
        try {

            String pathEscalas = System.getProperty("user.dir") + File.separator + "EscalasDefault";
            File fileEscalas = new File(pathEscalas);
            File ultimoArq = fileEscalas.listFiles()[0];

            for (File listFile : fileEscalas.listFiles()) {
                if (ultimoArq.lastModified() < listFile.lastModified()) {
                    ultimoArq = listFile;
                }
            }
            
            BufferedReader br = new BufferedReader(new FileReader(ultimoArq));
            String[] escalaArray;
            while(br.ready()) {
                escalaArray = br.readLine().split(";");
                escalas.add(new Escala(Integer.valueOf(escalaArray[0]),escalaArray[1],escalaArray[2]));
            }
            
            try {
                SimpleDateFormat formata = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
                Calendar dataEscala = new GregorianCalendar();
                Calendar dataAtual = new GregorianCalendar();
                Date data = new GregorianCalendar().getTime();

                for (int i = escalas.size(); i >0; i--) {
                    dataAtual.setTime(formata.parse(formata.format(data)));
                    dataEscala.setTime(formata.parse(escalas.get(0).getData() + " " + escalas.get(0).getHora() + ":00"));
                    if (dataAtual.getTimeInMillis() > dataEscala.getTimeInMillis()) {
                        escalas.remove(0);
                    }
                }

            } catch (ParseException ex) {
                Logger.getLogger(RotinaMostrarTempoRestante.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(EscalaService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(EscalaService.class.getName()).log(Level.SEVERE, null, ex);
        }

        return escalas;
    }

    @Override
    public void setHoraMinutosLabel(JLabel label) {
        ScheduledExecutorService loadLabelHoraAtual = Executors.newSingleThreadScheduledExecutor();
        loadLabelHoraAtual.scheduleAtFixedRate(new Runnable() {
            @Override
            public void run() {
                label.setText(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(Calendar.getInstance().getTime()));
            }
        }, 0, 1, TimeUnit.SECONDS);
    }

}
