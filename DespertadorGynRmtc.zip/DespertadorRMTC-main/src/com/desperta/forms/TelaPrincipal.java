package com.desperta.forms;

import com.desperta.model.Escala;
import com.desperta.service.EscalaService;
import com.desperta.util.ManagerFileDespertador;
import static com.desperta.util.ManagerFileDespertador.LOCAL_PROJETO;
import static com.desperta.util.ManagerFileDespertador.NOME_PASTA_ESCALADH;
import static com.desperta.util.ManagerFileDespertador.NOME_PASTA_ESCALA_C;
import com.desperta.util.Musica;
import com.desperta.util.RotinaMostrarTempoRestante;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Point;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListModel;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

/**
 *
 * @author hallef
 */
public class TelaPrincipal extends javax.swing.JFrame {

    private Musica musica;
    private ManagerFileDespertador managerFileDespertador;
    private EscalaService escalaService;
    private List<Escala> listEsclas;
    private DefaultListModel defaultListModelEscala;
    private final Point point;
    private RotinaMostrarTempoRestante mostrarTempoRestante;

    @SuppressWarnings("OverridableMethodCallInConstructor")
    public TelaPrincipal() {
        initComponents();
        setLocationRelativeTo(null);
        point = new Point();
        musica = new Musica();
        managerFileDespertador = new ManagerFileDespertador();
        escalaService = new EscalaService();
        defaultListModelEscala = new DefaultListModel();
        listEsclas = new ArrayList<>();
        labelGif.setVisible(false);
        escalaService.setHoraMinutosLabel(labelHoraAtual);
        TableColumnModel cm = jtbescalas.getColumnModel();
        while (cm.getColumnCount() != 0) {
            TableColumn column = cm.getColumn(0);
            cm.removeColumn(column);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jtbpane = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        btnImportar = new javax.swing.JButton();
        tfCaminhoArquivoMusica = new javax.swing.JTextField();
        btnExtrairPdf = new javax.swing.JButton();
        tfCaminhoArquivo = new javax.swing.JTextField();
        btnImportarMusica1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jListEscala = new javax.swing.JList<>();
        btnSairAbaImp = new javax.swing.JButton();
        lbTocarMusica = new javax.swing.JLabel();
        lbStopMusic = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        panelHoras = new javax.swing.JPanel();
        panelHoraEscala = new javax.swing.JPanel();
        labelHoraEscala = new javax.swing.JLabel();
        panelHoraSistema = new javax.swing.JPanel();
        labelHoraAtual = new javax.swing.JLabel();
        lbDisplay = new javax.swing.JLabel();
        lbmessage = new javax.swing.JLabel();
        labelGif = new javax.swing.JLabel();
        btnSairAbaAc = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jtbescalas = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                formMouseDragged(evt);
            }
        });
        addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                formMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                formMouseReleased(evt);
            }
        });

        jtbpane.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jtbpane.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jtbpaneStateChanged(evt);
            }
        });
        jtbpane.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jtbpaneMousePressed(evt);
            }
        });

        btnImportar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/desperta/icons/procurarPdf.png"))); // NOI18N
        btnImportar.setText("Importar");
        btnImportar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnImportarActionPerformed(evt);
            }
        });

        tfCaminhoArquivoMusica.setEditable(false);
        tfCaminhoArquivoMusica.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tfCaminhoArquivoMusica.setForeground(new java.awt.Color(255, 0, 0));
        tfCaminhoArquivoMusica.setToolTipText("Caminho do arquivo");

        btnExtrairPdf.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/desperta/icons/pdf Extrair.png"))); // NOI18N
        btnExtrairPdf.setText("Extrair");
        btnExtrairPdf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExtrairPdfActionPerformed(evt);
            }
        });

        tfCaminhoArquivo.setEditable(false);
        tfCaminhoArquivo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tfCaminhoArquivo.setForeground(new java.awt.Color(255, 0, 0));
        tfCaminhoArquivo.setToolTipText("Caminho do arquivo");

        btnImportarMusica1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/desperta/icons/negocios-e-financas.png"))); // NOI18N
        btnImportarMusica1.setText("Importar");
        btnImportarMusica1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnImportarMusica1ActionPerformed(evt);
            }
        });

        jListEscala.setBackground(new java.awt.Color(0, 0, 0));
        jListEscala.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createTitledBorder("Escala"), "Escalas válidas", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12), new java.awt.Color(51, 153, 0))); // NOI18N
        jListEscala.setFont(new java.awt.Font("Alef", 1, 14)); // NOI18N
        jListEscala.setForeground(new java.awt.Color(0, 153, 0));
        jScrollPane1.setViewportView(jListEscala);

        btnSairAbaImp.setBackground(new java.awt.Color(255, 51, 51));
        btnSairAbaImp.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/desperta/icons/desliga1.png"))); // NOI18N
        btnSairAbaImp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSairAbaImpActionPerformed(evt);
            }
        });

        lbTocarMusica.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbTocarMusica.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/desperta/icons/fones-de-ouvido.png"))); // NOI18N
        lbTocarMusica.setToolTipText("Tocar música");
        lbTocarMusica.setEnabled(false);
        lbTocarMusica.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbTocarMusicaMouseClicked(evt);
            }
        });

        lbStopMusic.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbStopMusic.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/desperta/icons/silent.png"))); // NOI18N
        lbStopMusic.setToolTipText("Parar música");
        lbStopMusic.setEnabled(false);
        lbStopMusic.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbStopMusicMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnSairAbaImp))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnExtrairPdf, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(btnImportar, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(tfCaminhoArquivo))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(btnImportarMusica1, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(tfCaminhoArquivoMusica, javax.swing.GroupLayout.PREFERRED_SIZE, 327, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lbTocarMusica, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lbStopMusic, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnImportar)
                    .addComponent(tfCaminhoArquivo, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tfCaminhoArquivoMusica, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnImportarMusica1)
                    .addComponent(lbTocarMusica, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbStopMusic, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(38, 38, 38)
                .addComponent(btnExtrairPdf)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 232, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnSairAbaImp, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6))
        );

        jtbpane.addTab("Importar", jPanel1);

        panelHoras.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), "Cronograma"));

        panelHoraEscala.setBackground(new java.awt.Color(0, 0, 0));
        panelHoraEscala.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 3, 2, new java.awt.Color(255, 255, 255)));

        labelHoraEscala.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        labelHoraEscala.setForeground(new java.awt.Color(0, 255, 51));
        labelHoraEscala.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelHoraEscala.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Hora escala", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 10), new java.awt.Color(255, 255, 255))); // NOI18N

        javax.swing.GroupLayout panelHoraEscalaLayout = new javax.swing.GroupLayout(panelHoraEscala);
        panelHoraEscala.setLayout(panelHoraEscalaLayout);
        panelHoraEscalaLayout.setHorizontalGroup(
            panelHoraEscalaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(labelHoraEscala, javax.swing.GroupLayout.DEFAULT_SIZE, 131, Short.MAX_VALUE)
        );
        panelHoraEscalaLayout.setVerticalGroup(
            panelHoraEscalaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(labelHoraEscala, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        panelHoraSistema.setBackground(new java.awt.Color(0, 0, 0));
        panelHoraSistema.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 3, 2, new java.awt.Color(255, 255, 255)));

        labelHoraAtual.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        labelHoraAtual.setForeground(new java.awt.Color(0, 255, 51));
        labelHoraAtual.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelHoraAtual.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Hora atual", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 10), new java.awt.Color(255, 255, 255))); // NOI18N

        javax.swing.GroupLayout panelHoraSistemaLayout = new javax.swing.GroupLayout(panelHoraSistema);
        panelHoraSistema.setLayout(panelHoraSistemaLayout);
        panelHoraSistemaLayout.setHorizontalGroup(
            panelHoraSistemaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(labelHoraAtual, javax.swing.GroupLayout.DEFAULT_SIZE, 131, Short.MAX_VALUE)
        );
        panelHoraSistemaLayout.setVerticalGroup(
            panelHoraSistemaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(labelHoraAtual, javax.swing.GroupLayout.DEFAULT_SIZE, 41, Short.MAX_VALUE)
        );

        lbDisplay.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lbDisplay.setForeground(new java.awt.Color(153, 0, 153));
        lbDisplay.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbDisplay.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Fique ligado!", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.DEFAULT_POSITION));

        lbmessage.setFont(new java.awt.Font("Consolas", 0, 12)); // NOI18N
        lbmessage.setForeground(new java.awt.Color(255, 51, 0));
        lbmessage.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbmessage.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Mensagem!", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 10))); // NOI18N
        lbmessage.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbmessageMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lbmessageMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lbmessageMouseExited(evt);
            }
        });

        labelGif.setForeground(new java.awt.Color(204, 204, 204));
        labelGif.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/desperta/icons/ajax-loader.gif"))); // NOI18N
        labelGif.setText(" Tocando...");

        btnSairAbaAc.setBackground(new java.awt.Color(255, 51, 51));
        btnSairAbaAc.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/desperta/icons/desliga2.png"))); // NOI18N
        btnSairAbaAc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSairAbaAcActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelHorasLayout = new javax.swing.GroupLayout(panelHoras);
        panelHoras.setLayout(panelHorasLayout);
        panelHorasLayout.setHorizontalGroup(
            panelHorasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelHorasLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelHorasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbDisplay, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelHorasLayout.createSequentialGroup()
                        .addComponent(panelHoraEscala, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(14, 14, 14)
                        .addComponent(panelHoraSistema, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(labelGif)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnSairAbaAc, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lbmessage, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        panelHorasLayout.setVerticalGroup(
            panelHorasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelHorasLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelHorasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(panelHoraEscala, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(labelGif, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelHorasLayout.createSequentialGroup()
                        .addGroup(panelHorasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnSairAbaAc)
                            .addComponent(panelHoraSistema, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lbDisplay, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbmessage, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), "Escalas"));

        jtbescalas.setBackground(new java.awt.Color(0, 0, 0));
        jtbescalas.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jtbescalas.setForeground(new java.awt.Color(0, 153, 0));
        jtbescalas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "DATA", "HORA"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jtbescalas.setRowHeight(40);
        jScrollPane2.setViewportView(jtbescalas);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 535, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 206, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(panelHoras, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(panelHoras, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jtbpane.addTab("Acompanhamento", jPanel2);

        jLabel1.setFont(new java.awt.Font("Alef", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 102, 0));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/desperta/icons/cronometro.png"))); // NOI18N
        jLabel1.setText("Despertador Manager");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 102, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("RMTC GYN");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(87, 87, 87)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addComponent(jtbpane)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(4, 4, 4)
                .addComponent(jtbpane)
                .addGap(9, 9, 9))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnImportarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnImportarActionPerformed
        JFileChooser fc = new JFileChooser();
        FileNameExtensionFilter filter = new FileNameExtensionFilter("pdf", "pdf","txt");
        fc.setFileFilter(filter);
        fc.setPreferredSize(new Dimension(800, 600));
        fc.setDialogTitle("Escala");
        int returnVal = fc.showOpenDialog(this);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
            btnImportar.setBackground(null);
            //btnImportar.setBorder(UIManager.getBorder("Button.border"));
            if (!defaultListModelEscala.isEmpty()) {
                defaultListModelEscala.removeAllElements();
            }
            tfCaminhoArquivo.setText(fc.getSelectedFile().getPath());
        }
    }//GEN-LAST:event_btnImportarActionPerformed

    private void btnSairAbaImpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSairAbaImpActionPerformed
        int op = JOptionPane.showConfirmDialog(null, "Deseja realmente sair?", "Sair do sistema", JOptionPane.YES_NO_OPTION);
        if (op == 0) {
            String[] arq = {LOCAL_PROJETO + File.separator + NOME_PASTA_ESCALA_C, LOCAL_PROJETO + File.separator + NOME_PASTA_ESCALADH, LOCAL_PROJETO + File.separator + "Music"};
            managerFileDespertador.deletePastas(arq);
            System.exit(0);
        }
    }//GEN-LAST:event_btnSairAbaImpActionPerformed

    private void lbTocarMusicaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbTocarMusicaMouseClicked
        if (lbTocarMusica.isEnabled()) {
            musica.setCaminho(tfCaminhoArquivoMusica.getText());
            musica.start();
            lbTocarMusica.setEnabled(false);
            lbStopMusic.setEnabled(true);
        }
    }//GEN-LAST:event_lbTocarMusicaMouseClicked

    private void lbStopMusicMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbStopMusicMouseClicked
        if (lbStopMusic.isEnabled()) {
            musica.close();
            lbTocarMusica.setEnabled(true);
            lbStopMusic.setEnabled(false);
            musica = new Musica();
        }
    }//GEN-LAST:event_lbStopMusicMouseClicked

    private void btnExtrairPdfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExtrairPdfActionPerformed

        if (!defaultListModelEscala.isEmpty()) {
            defaultListModelEscala.removeAllElements();
        }
        try {
            if (tfCaminhoArquivo.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "É necessário uma escala!");
                btnImportar.setBackground(Color.RED);
            } else if (tfCaminhoArquivoMusica.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "É necessário um toque!");
                btnImportarMusica1.setBackground(Color.RED);
            } else {
                btnImportar.setBorder(UIManager.getBorder("Button.border"));
                btnImportar.setBackground(null);
                managerFileDespertador.escalaComun(tfCaminhoArquivo.getText());
                listEsclas = escalaService.escalas();
                if (listEsclas.size() > 0) {
                    listEsclas.forEach((escala) -> {
                        String strEscala = String.format("Id  %s \t Data  %s \t Hora %s", escala.getId(), escala.getData(), escala.getHora());
                        defaultListModelEscala.addElement(strEscala);
                        jListEscala.setModel(defaultListModelEscala);
                    });
                } else {
                    JOptionPane.showMessageDialog(null, "As datas desta escala estão menor que a data atual!");
                }
            }

        } catch (IOException ex) {
            Logger.getLogger(TelaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnExtrairPdfActionPerformed

    private void formMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMousePressed
        point.x = evt.getX();
        point.y = evt.getY();
    }//GEN-LAST:event_formMousePressed

    private void formMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseReleased
        setOpacity(1f);
    }//GEN-LAST:event_formMouseReleased

    private void formMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseDragged
        setOpacity(0.7f);
        Point p = getLocation();
        setLocation(p.x + evt.getX() - point.x, p.y + evt.getY() - point.y);
    }//GEN-LAST:event_formMouseDragged

    private void jtbpaneMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtbpaneMousePressed

    }//GEN-LAST:event_jtbpaneMousePressed

    private void btnImportarMusica1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnImportarMusica1ActionPerformed
        JFileChooser fc = new JFileChooser();
        FileNameExtensionFilter filter = new FileNameExtensionFilter("mp3", "mp3");
        fc.setFileFilter(filter);
        fc.setPreferredSize(new Dimension(800, 600));
        fc.setDialogTitle("Música");
        int returnVal = fc.showOpenDialog(this);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
            btnImportarMusica1.setBorder(UIManager.getBorder("Button.border"));
            File file = fc.getSelectedFile();
            tfCaminhoArquivoMusica.setText(file.getPath());
            managerFileDespertador.copiador(tfCaminhoArquivoMusica.getText());
            lbTocarMusica.setEnabled(true);
            musica.close();
            lbTocarMusica.setEnabled(true);
            lbStopMusic.setEnabled(false);
            musica = new Musica();

        }
    }//GEN-LAST:event_btnImportarMusica1ActionPerformed

    private void jtbpaneStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jtbpaneStateChanged
        if (jtbpane.getSelectedIndex() == 1 && listEsclas.size() > 0) {
            if (mostrarTempoRestante == null) {
                mostrarTempoRestante = new RotinaMostrarTempoRestante(listEsclas, lbDisplay, lbmessage, labelGif, labelHoraEscala, jtbescalas);
                if (!mostrarTempoRestante.isAlive()) {
                    lbmessage.setText("");
                    mostrarTempoRestante.start();
                }
            }
            if(defaultListModelEscala.getSize() == 0) {
                lbmessage.setCursor(new Cursor(Cursor.HAND_CURSOR));
                lbmessage.setText("Começe a importar agora!");
            }
        }
    }//GEN-LAST:event_jtbpaneStateChanged

    private void btnSairAbaAcActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSairAbaAcActionPerformed
        int op = JOptionPane.showConfirmDialog(null, "Deseja realmente sair?", "Sair do sistema", JOptionPane.YES_NO_OPTION);
        if (op == 0) {
            String[] arq = {LOCAL_PROJETO + File.separator + NOME_PASTA_ESCALA_C, LOCAL_PROJETO + File.separator + NOME_PASTA_ESCALADH, LOCAL_PROJETO + File.separator + "Music"};
            managerFileDespertador.deletePastas(arq);
            System.exit(0);
        }
    }//GEN-LAST:event_btnSairAbaAcActionPerformed

    private void lbmessageMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbmessageMouseEntered
        if (defaultListModelEscala.getSize() == 0) {
            lbmessage.setCursor(new Cursor(Cursor.HAND_CURSOR));
            lbmessage.setText("Começe a importar agora!");
        }
    }//GEN-LAST:event_lbmessageMouseEntered

    private void lbmessageMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbmessageMouseExited
        if (defaultListModelEscala.getSize() == 0) {
            lbmessage.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
            lbmessage.setText("Começe a importar agora!");
        }
    }//GEN-LAST:event_lbmessageMouseExited

    private void lbmessageMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbmessageMouseClicked
        if(defaultListModelEscala.getSize() == 0) {
            jtbpane.setSelectedIndex(0);
        }
    }//GEN-LAST:event_lbmessageMouseClicked

    public static void main(String args[]) {

        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(() -> {
            new TelaPrincipal().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnExtrairPdf;
    private javax.swing.JButton btnImportar;
    private javax.swing.JButton btnImportarMusica1;
    private javax.swing.JButton btnSairAbaAc;
    private javax.swing.JButton btnSairAbaImp;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JList<String> jListEscala;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jtbescalas;
    private javax.swing.JTabbedPane jtbpane;
    private javax.swing.JLabel labelGif;
    private javax.swing.JLabel labelHoraAtual;
    private javax.swing.JLabel labelHoraEscala;
    private javax.swing.JLabel lbDisplay;
    private javax.swing.JLabel lbStopMusic;
    private javax.swing.JLabel lbTocarMusica;
    private javax.swing.JLabel lbmessage;
    private javax.swing.JPanel panelHoraEscala;
    private javax.swing.JPanel panelHoraSistema;
    private javax.swing.JPanel panelHoras;
    private javax.swing.JTextField tfCaminhoArquivo;
    private javax.swing.JTextField tfCaminhoArquivoMusica;
    // End of variables declaration//GEN-END:variables
}

//    public class PopupDeleteItem extends JList<Object> {
//        @Override
//        public JPopupMenu getComponentPopupMenu() {
//            JPopupMenu popup = new JPopupMenu();
//            JMenuItem removeItem = new JMenuItem("Excluir escala?");
//            removeItem.addActionListener(new ActionListener() {
//                @Override
//                public void actionPerformed(ActionEvent e) {
//                    int index = jListEscala.getSelectedIndex();
//                    int length = jListEscala.getModel().getSize();
//
//                    if (length > 0 && index != -1) {
//                        if (jListEscala.getModel().getSize() > 1) {
//                            defaultListModelEscala.remove(index);
//                            jListEscala.setModel(defaultListModelEscala);
//                        } else {
//                            jListEscala.remove(0);
//                            defaultListModelEscala.remove(0);
//                            jListEscala.setModel(defaultListModelEscala);
//                        }
//                    } else if (length > 0 && index == -1) {
//                        JOptionPane.showMessageDialog(null, "Selecione uma escala!");
//                    } else if (length == 0 && index == -1) {
//                        JOptionPane.showMessageDialog(null, "Faça a importação de uma escala!");
//                    }
//                }
//            });
//            popup.add(removeItem);
//            return popup;
//        }
//    }
