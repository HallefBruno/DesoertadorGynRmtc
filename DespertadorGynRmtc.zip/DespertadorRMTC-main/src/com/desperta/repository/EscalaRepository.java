package com.desperta.repository;

import com.desperta.model.Escala;
import java.util.List;
import javax.swing.JLabel;

/**
 *
 * @author hallef
 */
public interface EscalaRepository {
    
    public void save(List<Escala> escala);
    public List<Escala> escalas();
    public void setHoraMinutosLabel(JLabel label);
}
